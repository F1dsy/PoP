Name: Alexander Bang (dkg213), Thor Gregersen (mxb267)

We have focused on meeting all the requirements given by the assignment. 
There is implemented an abstract Step class to make it clearer that all of the others are of the same interface.
We have not implemented error handling as it seemed unneccesary for the scope of this assignment. 

In our tests we have focused on,, that every Step gives the correct result and the correct description. 
Not focusing on edge cases that require error handling.

To run test:
run "py testPipeline.py" in command line, while in same folder.