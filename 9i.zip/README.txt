Navn: Alexander Bang dkg213
Dato: 09.12.2022
Hvordan man kører projektet:
 - For at bygge projektet skal man skrive "dotnet build"
 - For at køre projektet skal man skrive "dotnet run". Det vil både gennemføre alle tests og simulere.
