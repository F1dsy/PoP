Navn: Alexander Bang, Thor Gregersen
Dato: 05.11.2022
To Build: dotnet build
to Run: dotnet run