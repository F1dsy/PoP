Navn: Alexander Bang
To build the project go to command line and run "dotnet build"
To run the project go to command line and run "dotnet run".